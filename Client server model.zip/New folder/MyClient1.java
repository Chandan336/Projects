import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class MyClient1 {
    public static void main(String[] args) throws Exception {
       
            try {
                Socket s2 = new Socket("192.168.148.237",3333);

        System.out.println("Start Chatting");
       
        DataInputStream din =new DataInputStream(s2.getInputStream());
        DataOutputStream dout = new DataOutputStream(s2.getOutputStream());
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String str = "" , str2 = "" ;
        while (!str.equals("stop")) {
            str = br.readLine();
            dout.writeUTF(str);
            dout.flush();
            str2 = din.readUTF();
        
        System.out.println("Server : "+str2);

            
        }

        dout.close();
        s2.close();
        
            
        } 
        catch (Exception e) {
            System.out.println("Server is not Responding");
        }
    }
}
