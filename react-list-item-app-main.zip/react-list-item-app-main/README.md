# react-list-item-app

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/react-list-item-app)